﻿namespace Atividade_
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblGratificao = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblProdução = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtGratificacao = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtProducao = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblNome.Location = new System.Drawing.Point(16, 43);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(55, 20);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome:";
            this.lblNome.Click += new System.EventHandler(this.lblNome_Click);
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblMatricula.Location = new System.Drawing.Point(16, 96);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(81, 20);
            this.lblMatricula.TabIndex = 1;
            this.lblMatricula.Text = "Mátricula: ";
            // 
            // lblGratificao
            // 
            this.lblGratificao.AutoSize = true;
            this.lblGratificao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblGratificao.Location = new System.Drawing.Point(16, 271);
            this.lblGratificao.Name = "lblGratificao";
            this.lblGratificao.Size = new System.Drawing.Size(103, 20);
            this.lblGratificao.TabIndex = 2;
            this.lblGratificao.Text = "Gratificação: ";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblSalario.Location = new System.Drawing.Point(16, 214);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(66, 20);
            this.lblSalario.TabIndex = 3;
            this.lblSalario.Text = "Salário: ";
            this.lblSalario.Click += new System.EventHandler(this.lblSalario_Click);
            // 
            // lblProdução
            // 
            this.lblProdução.AutoSize = true;
            this.lblProdução.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblProdução.Location = new System.Drawing.Point(16, 155);
            this.lblProdução.Name = "lblProdução";
            this.lblProdução.Size = new System.Drawing.Size(85, 20);
            this.lblProdução.TabIndex = 4;
            this.lblProdução.Text = "Produção: ";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(129, 45);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(284, 20);
            this.txtNome.TabIndex = 5;
            // 
            // txtGratificacao
            // 
            this.txtGratificacao.Location = new System.Drawing.Point(129, 273);
            this.txtGratificacao.Name = "txtGratificacao";
            this.txtGratificacao.Size = new System.Drawing.Size(284, 20);
            this.txtGratificacao.TabIndex = 6;
            this.txtGratificacao.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(129, 214);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(284, 20);
            this.txtSalario.TabIndex = 7;
            // 
            // txtProducao
            // 
            this.txtProducao.Location = new System.Drawing.Point(129, 157);
            this.txtProducao.Name = "txtProducao";
            this.txtProducao.Size = new System.Drawing.Size(284, 20);
            this.txtProducao.TabIndex = 8;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(129, 98);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(284, 20);
            this.txtMatricula.TabIndex = 9;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(301, 363);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(166, 50);
            this.btnCalcular.TabIndex = 10;
            this.btnCalcular.Text = "Calcular Sálario Bruto";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.txtProducao);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtGratificacao);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblProdução);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblGratificao);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.lblNome);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.Load += new System.EventHandler(this.frmExercicio4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblGratificao;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblProdução;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtGratificacao;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtProducao;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Button btnCalcular;
    }
}