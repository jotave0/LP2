﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int N;
            double H = 0.0;
            if (int.TryParse(txtQntd.Text, out N))
            {
                if (N > 0)
                {
                    for (int i = 1; i <= N; i++)
                    {
                        H += 1.0 / i;
                    }
                    MessageBox.Show($"O Valor de H é: {H:F4}");
                }
                else
                {
                    MessageBox.Show("Digite um número maior que 0!");
                }
            }
            else
            {
                MessageBox.Show("Digite um número inteiro válido!");
            }
        }
    }
}
