﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercício4 : Form
    {
        public frmExercício4()
        {
            InitializeComponent();
        }

        private void btnContarNumeros_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contNum = 0;
            
            while (contador < rchtxtFrase.Text.Length)
            {
                if ( Char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contNum++; 
                }
                contador++;
            }
            MessageBox.Show($"O texto tem {contNum} números");

        }

        private void btnPosicaoDo1_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao= i+1;
                    break;
                }
            }
            MessageBox.Show($"A posição do 1° caracter em branco é {posicao}");
        }

        private void btnContarLetras_Click(object sender, EventArgs e)
        {
            int contaLetra = 0; 
            foreach ( char c in rchtxtFrase.Text )
            {
                if(Char.IsLetter(c))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"O termo tem {contaLetra} letras");
        }
    }
}
