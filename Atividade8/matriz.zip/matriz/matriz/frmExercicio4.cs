﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace matriz
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            string[] aux = new string[10];
            for (int i = 0; i < 10; i++) 
            {
               nomes[i] = Interaction.InputBox("Digite o nome completo: ");
               aux[i] = nomes[i].Replace(" ", ""); 

            }
            for (int i = 0; i < 10; i++)
            {
                lboxNomes.Items.Add($"o  nome {nomes[i]} tem: {aux[i].Length} caracteres ");
            }



        }
    }
}
