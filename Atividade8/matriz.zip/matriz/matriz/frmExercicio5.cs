﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace matriz
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int N = 2;
            string[,] respostas = new string[N,10];
            string[] gabarito = { "A", "B", "A", "A", "C", "D", "A", "D", "E", "E" };

            for (int i = 0; i < N; i++) 
                for (int j = 0; j < 10; j++)
                {
                    respostas[i, j] = (Interaction.InputBox($"DIgite a resposta da questão {j + 1} do  aluno {i + 1}")).ToUpper();

                    if (respostas[i, j] != "A" &&
                        respostas[i, j] != "B" &&
                        respostas[i, j] != "C" &&
                        respostas[i, j] != "D" &&
                        respostas[i, j] != "E" )
                    {
                        j--;
                    } 
                }
            for (int i = 0; i < N; i++)
                for (int j = 0; j < 10; j++)
                {
                    if (respostas[i, j] == gabarito[j])
                    {
                        lboxNotas.Items.Add($"O aluno {i + 1} acertou a questão {j + 1}: era {gabarito[j]} e escolheu {gabarito[j]}");
                    }
                    else
                    {
                        lboxNotas.Items.Add($"O aluno {i + 1} errou a questão {j + 1}: era {gabarito[j]} e escolheu {respostas[i,j]}");
                    }
                }


        }
    }
}
