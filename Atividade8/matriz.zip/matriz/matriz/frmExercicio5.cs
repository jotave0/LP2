﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace matriz
{
    public partial class frmExercicio5: Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int N = 2;
            string[,] respostas = new string[N, 10];
            string[] gabarito = new string[10];

            for(int i = 0; i < 10; i++)
            {
                gabarito[i] = Interaction.InputBox($"Digite o gabarito da questao {i + 1}:  ");
            }
            for (int i = 0; i < N; i++)
              for (int j = 0; j < 10; j++)
                {
                    respostas[i, j] = Interaction.InputBox($"Digite a resposta da questão {j + 1} do aluno {i + 1}");
                }
            for (int i = 0; i < N; i++)
                for (int j = 0; j < 10; j++)
                {
                    if (respostas[i, j].ToUpper() == gabarito[j].ToUpper())
                    {
                        lboxGabarito.Items.Add($"O Aluno {i + 1} acertou a questão {j + 1}: era {gabarito[j]} e escolheu {gabarito[j]}");
                    }
                    else
                    {
                        lboxGabarito.Items.Add($"O Aluno {i + 1} errou a questão {j + 1}: era {gabarito[j]} e escolheu {respostas[i, j]}");
                    }
                }





        }

        private void frmExercicio5_Load(object sender, EventArgs e)
        {

        }
    }
}
