﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace matriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}º numero ", "Entrada de Dados");
                if (auxiliar == "")
                {
                    break;
                }


                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Numero Inválido! ");
                    i--;
                }

            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int j in vetor)
            {
                auxiliar += j + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList()
            { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" };
            nomes.Remove("Otávio");
            string resultado = string.Join("\n", nomes.ToArray());
            MessageBox.Show(resultado);
        }

        private void btnNotas_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            double[] media = new double[20];
            string saida = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j + 1}ª nota do aluno {i + 1}");

                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Numero inválido! ");
                        j--;
                    }
                    else if (notas[i, j] < 0 && notas[i, j] > 10)
                    {
                        MessageBox.Show("Numero inválido! ");
                        j--;
                    }
                    else
                        media[i] += notas[i, j];
                }
                media[i] = media[i] / 3;
                saida += "A média do Aluno " + (i + 1) + " é : " + media[i].ToString("N2") + "\n";


            }
            MessageBox.Show(saida);



        }

        private void button4_Click(object sender, EventArgs e)
        {
            new frmExercicio4().ShowDialog(); 
        }

        private void button5_Click(object sender, EventArgs e)
        {
            new frmExercicio5().ShowDialog();
        }
    }
}
