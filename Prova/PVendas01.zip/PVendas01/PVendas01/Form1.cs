﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas01
{
    public partial class Vendas : Form
    {
        public Vendas()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lboxTabela.Items.Clear(); 
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] tabVendas = new double[3,4];
            double[] aux = new double[3];
            double totalMes;
            double totalGeral = 0;

            for (int i = 0; i < 3; i++) {
                aux[i] = 0;
                for (int j = 0; j < 4; j++)
                {
                    if (!double.TryParse(Interaction.InputBox($"Total do mês {i + 1} Semana {j + 1}:"), out tabVendas[i, j]) || (tabVendas[i, j] < 0))
                    {
                        MessageBox.Show("Valor inválido!");
                        j--;
                    }else
                    aux[i] += tabVendas[i, j];
                }
                
            }
            for (int i = 0; i < 3; i++)
            {
                totalMes = aux[i];
                for (int j = 0; j < 4; j++)
                {
                    lboxTabela.Items.Add($"Total mês {i + 1} Semana {j + 1} : {tabVendas[i, j].ToString("N2")}");
                    

                }
                lboxTabela.Items.Add($">> Total Mês: {totalMes.ToString("N2")}");
                lboxTabela.Items.Add("-----------------------");
                totalGeral += totalMes;
            }
            lboxTabela.Items.Add($">>Total Geral:{totalGeral.ToString("N2")}");

        }
    }
}
    